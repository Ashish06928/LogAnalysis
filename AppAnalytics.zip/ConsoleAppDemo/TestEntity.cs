﻿using System;

namespace ConsoleAppDemo
{
    public class TestEntity
    {
        public string Category { get; set; }
        public string TestString { get; set; }
        public bool TestBoolean { get; set; }
        public DateTime TestDateTime { get; set; }
        public double TestDouble { get; set; }
        public Guid TestGuid { get; set; }
    }
}
